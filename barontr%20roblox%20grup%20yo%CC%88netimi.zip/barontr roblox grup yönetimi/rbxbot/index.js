'use strict';

require('dotenv').config();

const { Client, GatewayIntentBits, Collection, Events, ActivityType, MessageFlags } = require('discord.js');
const fs = require('fs');
const path = require('path');

const vault = require('./core/vault');
const logger = require('./utils/logger');

vault.validateConfig();

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages
  ],
  allowedMentions: { parse: ['users'], repliedUser: true }
});

client.commands = new Collection();
client.cooldowns = new Collection();

const cmdDir = path.join(__dirname, 'commands');
const cmdFiles = fs.readdirSync(cmdDir).filter(function(f) { return f.endsWith('.js'); });

for (var i = 0; i < cmdFiles.length; i++) {
  try {
    var cmd = require(path.join(cmdDir, cmdFiles[i]));
    if (cmd && cmd.data && cmd.execute) {
      client.commands.set(cmd.data.name, cmd);
      console.log('[LOAD] /' + cmd.data.name + ' y\u00fcklendi.');
    }
  } catch (e) {
    console.error('[LOAD HATA]', cmdFiles[i], e.message);
  }
}

client.once(Events.ClientReady, async function(c) {
  console.log('[READY] ' + c.user.tag + ' \u00e7evrimi\u00e7i | ' + new Date().toLocaleString('tr-TR'));
  console.log('[INFO] ' + c.guilds.cache.size + ' sunucuda aktif.');

  try {
    c.user.setPresence({
      activities: [{ name: 'discord.gg/pEzT4WmWyn', type: ActivityType.Watching }],
      status: 'online'
    });
  } catch (_) {}

  await logger.logAction(null, {
    type: 'SISTEM',
    title: '\uD83D\uDFE2 Bot \u00c7evrimi\u00e7i',
    description: '**' + c.user.tag + '** ba\u015far\u0131yla ba\u015flat\u0131ld\u0131.',
    extra:
      'Node.js: `' + process.version + '`\n' +
      'Sunucu Say\u0131s\u0131: `' + c.guilds.cache.size + '`\n' +
      'Platform: `' + process.platform + '`'
  });
});

client.on(Events.InteractionCreate, async function(interaction) {
  if (interaction.isAutocomplete()) {
    var acCmd = client.commands.get(interaction.commandName);
    if (acCmd && acCmd.autocomplete) {
      try { await acCmd.autocomplete(interaction); } catch (_) {}
    }
    return;
  }

  if (!interaction.isChatInputCommand()) return;

  var command = client.commands.get(interaction.commandName);
  if (!command) return;

  var cdCol = client.cooldowns;
  if (!cdCol.has(command.data.name)) {
    cdCol.set(command.data.name, new Collection());
  }

  var now = Date.now();
  var timestamps = cdCol.get(command.data.name);
  var cdMs = (command.cooldown || 3) * 1000;
  var userId = interaction.user.id;

  if (timestamps.has(userId)) {
    var expiry = timestamps.get(userId) + cdMs;
    if (now < expiry) {
      var remaining = ((expiry - now) / 1000).toFixed(1);
      return interaction.reply({
        flags: MessageFlags.Ephemeral,
        embeds: [{
          color: 0xfee75c,
          title: '\u23f3 Bekleme S\u00fcresi Aktif',
          description: 'Bu komutu tekrar kullanabilmek i\u00e7in **' + remaining + ' saniye** beklemeniz gerekiyor.',
          fields: [{ name: '\uD83D\uDD17 Destek', value: '[discord.gg/pEzT4WmWyn](https://discord.gg/pEzT4WmWyn)', inline: true }],
          footer: { text: 'Made By discord.gg/pEzT4WmWyn' },
          timestamp: new Date().toISOString()
        }]
      });
    }
  }

  timestamps.set(userId, now);
  setTimeout(function() { timestamps.delete(userId); }, cdMs);

  try {
    await command.execute(interaction, client);
  } catch (err) {
    console.error('[CMD ERROR] /' + interaction.commandName + ':', err);

    await logger.logAction(null, {
      type: 'HATA',
      title: 'Komut \u00c7al\u0131\u015fma Hatas\u0131',
      description: '`/' + interaction.commandName + '` komutunda beklenmedik hata.',
      extra:
        'Kullan\u0131c\u0131: ' + interaction.user.tag + ' (' + interaction.user.id + ')\n' +
        'Sunucu: ' + (interaction.guild ? interaction.guild.name : 'DM') + '\n' +
        '```' + (err.message || String(err)).slice(0, 800) + '```'
    });

    var errEmbed = {
      color: 0xff4444,
      title: '\u274c Beklenmedik Hata',
      description: 'Komut \u00e7al\u0131\u015ft\u0131r\u0131l\u0131rken bir hata meydana geldi. L\u00fctfen tekrar deneyin.',
      fields: [{ name: '\uD83D\uDD17 Destek', value: '[discord.gg/pEzT4WmWyn](https://discord.gg/pEzT4WmWyn)' }],
      footer: { text: 'Made By discord.gg/pEzT4WmWyn' },
      timestamp: new Date().toISOString()
    };

    if (interaction.replied || interaction.deferred) {
      await interaction.followUp({ flags: MessageFlags.Ephemeral, embeds: [errEmbed] }).catch(function() {});
    } else {
      await interaction.reply({ flags: MessageFlags.Ephemeral, embeds: [errEmbed] }).catch(function() {});
    }
  }
});

client.on(Events.GuildCreate, async function(guild) {
  await logger.logAction(null, {
    type: 'SISTEM',
    title: '\uD83D\uDCE5 Yeni Sunucu',
    description: 'Bot yeni bir sunucuya eklendi.',
    extra: 'Sunucu: **' + guild.name + '**\n\u00dcye: `' + guild.memberCount + '`\nID: `' + guild.id + '`'
  });
});

client.on(Events.GuildDelete, async function(guild) {
  await logger.logAction(null, {
    type: 'SISTEM',
    title: '\uD83D\uDCE4 Sunucudan \u00c7\u0131kar\u0131ld\u0131',
    description: 'Bot bir sunucudan kald\u0131r\u0131ld\u0131.',
    extra: 'Sunucu: **' + (guild.name || 'Bilinmiyor') + '**\nID: `' + guild.id + '`'
  });
});

process.on('unhandledRejection', async function(reason) {
  console.error('[UNHANDLED REJECTION]', reason);
  await logger.logAction(null, {
    type: 'HATA',
    title: '\u26a0\ufe0f Unhandled Rejection',
    extra: '```' + String(reason).slice(0, 800) + '```'
  }).catch(function() {});
});

process.on('uncaughtException', async function(err) {
  console.error('[UNCAUGHT EXCEPTION]', err);
  await logger.logAction(null, {
    type: 'HATA',
    title: '\uD83D\uDD34 Uncaught Exception',
    extra: '```' + (err.message || String(err)).slice(0, 800) + '```'
  }).catch(function() {});
});

client.login(process.env.DISCORD_TOKEN).catch(async function(e) {
  console.error('[LOGIN HATA]', e.message);
  if (e.message && e.message.includes('TOKEN_INVALID')) {
    console.error('[LOGIN] DISCORD_TOKEN ge\u00e7ersiz. .env dosyas\u0131n\u0131 kontrol edin.');
  }
  await logger.logAction(null, {
    type: 'HATA',
    title: '\uD83D\uDD34 Giri\u015f Hatas\u0131',
    description: 'Discord token ile giri\u015f yap\u0131lamad\u0131.',
    extra: '```' + e.message + '```'
  }).catch(function() {});
  process.exit(1);
});
