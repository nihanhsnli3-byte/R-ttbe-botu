'use strict';

require('dotenv').config();

const { REST, Routes } = require('discord.js');
const fs = require('fs');
const path = require('path');

if (!process.env.DISCORD_TOKEN) {
  console.error('[DEPLOY] DISCORD_TOKEN bulunamadi. .env dosyasini kontrol edin.');
  process.exit(1);
}

const commands = [];
const cmdDir = path.join(__dirname, 'commands');
const cmdFiles = fs.readdirSync(cmdDir).filter(function(f) { return f.endsWith('.js'); });

for (var i = 0; i < cmdFiles.length; i++) {
  try {
    var cmd = require(path.join(cmdDir, cmdFiles[i]));
    if (cmd && cmd.data) {
      commands.push(cmd.data.toJSON());
      console.log('[DEPLOY] Yuklendi: /' + cmd.data.name);
    }
  } catch (e) {
    console.error('[DEPLOY] ' + cmdFiles[i] + ' yuklenemedi:', e.message);
  }
}

var tokenParts = process.env.DISCORD_TOKEN.split('.');
var appId;
try {
  appId = Buffer.from(tokenParts[0], 'base64').toString('utf8');
} catch (e) {
  console.error('[DEPLOY] Token gecersiz gorünüyor.');
  process.exit(1);
}

var rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);

rest.put(Routes.applicationCommands(appId), { body: commands })
  .then(function(data) {
    console.log('[DEPLOY] ' + data.length + ' komut basariyla Discord\'a kaydedildi.');
    console.log('[DEPLOY] Bot hazir! "npm start" ile calistirabilirsiniz.');
  })
  .catch(function(e) {
    console.error('[DEPLOY HATA]', e.message);
    if (e.message && e.message.indexOf('401') !== -1) {
      console.error('[DEPLOY] Token gecersiz. Discord Developer Portal\'dan kontrol edin.');
    }
  });
