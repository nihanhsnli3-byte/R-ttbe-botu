'use strict';

const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');
const vault = require('../core/vault');
const rbx = require('../utils/roblox');
const logger = require('../utils/logger');

module.exports = {
  cooldown: 75,

  data: new SlashCommandBuilder()
    .setName('r\u00fctbe-ver')
    .setDescription('Roblox grup \u00fcyesine belirli bir r\u00fctbe atar.')
    .addStringOption(function(o) {
      return o.setName('kullanici').setDescription('Roblox kullan\u0131c\u0131 ad\u0131').setRequired(true);
    })
    .addStringOption(function(o) {
      return o.setName('rutbe').setDescription('Verilecek r\u00fctbeyi se\u00e7in').setRequired(true).setAutocomplete(true);
    })
    .addStringOption(function(o) {
      return o.setName('sart').setDescription('R\u00fctbe verme \u015fart\u0131 / notu').setRequired(true);
    })
    .addStringOption(function(o) {
      return o.setName('sebep').setDescription('R\u00fctbe verme sebebi').setRequired(true);
    }),

  async autocomplete(interaction) {
    try {
      const focused = (interaction.options.getFocused() || '').toLowerCase();
      const roles = await rbx.fetchGroupRoles();
      const filtered = roles
        .filter(function(r) { return r.rank > 0 && r.rank < 255 && r.name.toLowerCase().includes(focused); })
        .slice(0, 25)
        .map(function(r) { return { name: '[Rank ' + r.rank + '] ' + r.name, value: String(r.id) }; });
      await interaction.respond(filtered);
    } catch (_) {
      await interaction.respond([]).catch(function() {});
    }
  },

  async execute(interaction, client) {
    if (!vault.checkPermission(interaction.member)) {
      return interaction.reply({
        flags: MessageFlags.Ephemeral,
        embeds: [
          new EmbedBuilder()
            .setColor(0xff4444)
            .setTitle('\uD83D\uDEAB Yetki Yetersiz')
            .setDescription('Bu komutu kullanabilmek i\u00e7in gerekli role sahip de\u011filsiniz.')
            .addFields({ name: '\uD83D\uDD17 Destek', value: '[discord.gg/pEzT4WmWyn](https://discord.gg/pEzT4WmWyn)', inline: true })
            .setFooter({ text: 'Made By discord.gg/pEzT4WmWyn' })
            .setTimestamp()
        ]
      });
    }

    await interaction.deferReply();

    const username = interaction.options.getString('kullanici');
    const targetRoleId = parseInt(interaction.options.getString('rutbe'), 10);
    const sart = interaction.options.getString('sart');
    const sebep = interaction.options.getString('sebep');

    try {
      const user = await rbx.resolveUsername(username);
      if (!user) {
        return interaction.editReply({
          embeds: [
            new EmbedBuilder()
              .setColor(0xff4444)
              .setTitle('\u274c Kullan\u0131c\u0131 Bulunamad\u0131')
              .setDescription('**' + username + '** adl\u0131 bir Roblox hesab\u0131 bulunamad\u0131.')
              .setFooter({ text: 'Made By discord.gg/pEzT4WmWyn' })
              .setTimestamp()
          ]
        });
      }

      const allRoles = await rbx.fetchGroupRoles();
      const targetRole = allRoles.find(function(r) { return r.id === targetRoleId; });
      if (!targetRole) {
        return interaction.editReply({
          embeds: [
            new EmbedBuilder()
              .setColor(0xff4444)
              .setTitle('\u274c R\u00fctbe Bulunamad\u0131')
              .setDescription('Se\u00e7ilen r\u00fctbe grup i\u00e7inde mevcut de\u011fil.')
              .setFooter({ text: 'Made By discord.gg/pEzT4WmWyn' })
              .setTimestamp()
          ]
        });
      }

      const currentRole = await rbx.fetchUserRoleInGroup(user.id);
      await rbx.applyRoleToUser(user.id, targetRoleId);

      const embed = new EmbedBuilder()
        .setColor(0xfee75c)
        .setTitle('\uD83C\uDFC5 R\u00fctbe Ba\u015far\u0131yla Atand\u0131')
        .setDescription('**' + user.name + '** adl\u0131 kullan\u0131c\u0131ya ba\u015far\u0131yla r\u00fctbe atand\u0131.')
        .addFields(
          { name: '\uD83D\uDC64 Kullan\u0131c\u0131', value: user.name + '\n`ID: ' + user.id + '`', inline: true },
          { name: '\uD83C\uDFC5 Atanan R\u00fctbe', value: targetRole.name + '\n`Rank ' + targetRole.rank + '`', inline: true },
          { name: '\u200b', value: '\u200b', inline: true },
          { name: '\uD83D\uDCCB \u015eart', value: sart, inline: false },
          { name: '\uD83D\uDCDD Sebep', value: sebep, inline: false },
          { name: '\uD83D\uDD17 Destek Sunucusu', value: '[discord.gg/pEzT4WmWyn](https://discord.gg/pEzT4WmWyn)', inline: false }
        )
        .setFooter({ text: '\u0130\u015flemi Yapan: ' + interaction.user.tag + ' \u2022 Made By discord.gg/pEzT4WmWyn' })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });

      await logger.logAction(client, {
        type: 'RUTBE_VER',
        title: 'R\u00fctbe Atama',
        description: '**' + user.name + '** adl\u0131 kullan\u0131c\u0131ya r\u00fctbe atand\u0131.',
        executor: interaction.user,
        targetUser: user.name,
        targetId: user.id,
        oldRole: currentRole || { name: 'Bilinmiyor', rank: 0 },
        newRole: targetRole,
        reason: sebep,
        extra: '\u015eart: ' + sart,
        guild: interaction.guild ? interaction.guild.name : 'DM'
      });

    } catch (err) {
      await logger.logAction(null, {
        type: 'HATA',
        title: 'R\u00fctbe Ver Hatas\u0131',
        description: 'Kullan\u0131c\u0131: ' + username,
        extra: '```' + (err.message || String(err)) + '```'
      });

      return interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setColor(0xff4444)
            .setTitle('\u274c \u0130\u015flem Ba\u015far\u0131s\u0131z')
            .setDescription('R\u00fctbe atan\u0131rken hata olu\u015ftu:\n```' + (err.message || 'Bilinmeyen hata') + '```')
            .setFooter({ text: 'Made By discord.gg/pEzT4WmWyn' })
            .setTimestamp()
        ]
      });
    }
  }
};
