'use strict';

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const rbx = require('../utils/roblox');
const logger = require('../utils/logger');

function fmtNum(n) {
  if (typeof n !== 'number') return '0';
  return n.toLocaleString('tr-TR');
}

function buildBar(current, max) {
  if (!current || !max || max <= 0) return '`[\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591]` **0%**';
  const pct = Math.min(current / max, 1);
  const filled = Math.round(pct * 20);
  const empty = 20 - filled;
  const bar = '\u2588'.repeat(filled) + '\u2591'.repeat(empty);
  return '`[' + bar + ']` **' + (pct * 100).toFixed(1) + '%**';
}

module.exports = {
  cooldown: 10,

  data: new SlashCommandBuilder()
    .setName('aktiflik-sorgu')
    .setDescription('Roblox oyununun anl\u0131k aktiflik istatistiklerini g\u00f6sterir.'),

  async execute(interaction, client) {
    await interaction.deferReply();

    try {
      const data = await rbx.fetchGameStats();

      if (!data) {
        return interaction.editReply({
          embeds: [
            new EmbedBuilder()
              .setColor(0xff4444)
              .setTitle('\u274c Veri Al\u0131namad\u0131')
              .setDescription('Universe ID\'ye ait oyun verisi al\u0131namad\u0131. `.env` dosyan\u0131zdaki `UNIVERSE_ID` de\u011ferini kontrol edin.')
              .setFooter({ text: 'Made By discord.gg/pEzT4WmWyn' })
              .setTimestamp()
          ]
        });
      }

      const bar = buildBar(data.playing, data.maxPlayers);

      const embed = new EmbedBuilder()
        .setColor(0x00b4d8)
        .setTitle('\uD83C\uDFAE ' + data.name)
        .setDescription('Oyunun anl\u0131k Roblox istatistikleri a\u015fa\u011f\u0131da listelenmektedir.')
        .addFields(
          { name: '\uD83D\uDFE2 Anl\u0131k Aktif Oyuncu', value: '**' + fmtNum(data.playing) + '** ki\u015fi', inline: true },
          { name: '\uD83D\uDC65 Maks. Kapasite', value: fmtNum(data.maxPlayers) + ' ki\u015fi/sunucu', inline: true },
          { name: '\uD83D\uDCCA Doluluk Oran\u0131', value: bar, inline: false },
          { name: '\uD83C\uDFAF Toplam Ziyaret', value: fmtNum(data.visits), inline: true },
          { name: '\uD83C\uDFB2 T\u00fcr', value: data.genre, inline: true },
          { name: '\uD83C\uDF10 Universe ID', value: '`' + data.universeId + '`', inline: true },
          { name: '\uD83D\uDD17 Destek Sunucusu', value: '[discord.gg/pEzT4WmWyn](https://discord.gg/pEzT4WmWyn)', inline: false }
        )
        .setFooter({ text: 'Sorgu: ' + interaction.user.tag + ' \u2022 Made By discord.gg/pEzT4WmWyn' })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });

      await logger.logAction(client, {
        type: 'BILGI',
        title: '\uD83D\uDCCA Aktiflik Sorgusu',
        description: '**' + interaction.user.tag + '** aktiflik sorgusu yapt\u0131.',
        extra: 'Oyun: **' + data.name + '** \u2022 Oyuncu: **' + fmtNum(data.playing) + '**',
        guild: interaction.guild ? interaction.guild.name : 'DM'
      });

    } catch (err) {
      await logger.logAction(null, {
        type: 'HATA',
        title: 'Aktiflik Sorgu Hatas\u0131',
        extra: '```' + (err.message || String(err)) + '```'
      });

      return interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setColor(0xff4444)
            .setTitle('\u274c Veri Al\u0131namad\u0131')
            .setDescription('Aktiflik verisi al\u0131n\u0131rken sorun olu\u015ftu:\n```' + (err.message || 'Bilinmeyen hata') + '```')
            .setFooter({ text: 'Made By discord.gg/pEzT4WmWyn' })
            .setTimestamp()
        ]
      });
    }
  }
};
