'use strict';

const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');
const vault = require('../core/vault');
const rbx = require('../utils/roblox');
const logger = require('../utils/logger');

module.exports = {
  cooldown: 75,

  data: new SlashCommandBuilder()
    .setName('r\u00fctbe-tenzil')
    .setDescription('Roblox grup \u00fcyesini bir alt r\u00fctbeye tenzil eder.')
    .addStringOption(function(o) {
      return o.setName('kullanici').setDescription('Roblox kullan\u0131c\u0131 ad\u0131').setRequired(true);
    })
    .addStringOption(function(o) {
      return o.setName('sebep').setDescription('Tenzil sebebi').setRequired(true);
    }),

  async execute(interaction, client) {
    if (!vault.checkPermission(interaction.member)) {
      return interaction.reply({
        flags: MessageFlags.Ephemeral,
        embeds: [
          new EmbedBuilder()
            .setColor(0xff4444)
            .setTitle('\uD83D\uDEAB Yetki Yetersiz')
            .setDescription('Bu komutu kullanabilmek i\u00e7in gerekli role sahip de\u011filsiniz.')
            .addFields({ name: '\uD83D\uDD17 Destek', value: '[discord.gg/pEzT4WmWyn](https://discord.gg/pEzT4WmWyn)' })
            .setFooter({ text: 'Made By discord.gg/pEzT4WmWyn' })
            .setTimestamp()
        ]
      });
    }

    await interaction.deferReply();

    const username = interaction.options.getString('kullanici');
    const sebep = interaction.options.getString('sebep');

    try {
      const user = await rbx.resolveUsername(username);
      if (!user) {
        return interaction.editReply({
          embeds: [
            new EmbedBuilder()
              .setColor(0xff4444)
              .setTitle('\u274c Kullan\u0131c\u0131 Bulunamad\u0131')
              .setDescription('**' + username + '** adl\u0131 Roblox hesab\u0131 bulunamad\u0131.')
              .setFooter({ text: 'Made By discord.gg/pEzT4WmWyn' })
              .setTimestamp()
          ]
        });
      }

      const currentRole = await rbx.fetchUserRoleInGroup(user.id);
      if (!currentRole) {
        return interaction.editReply({
          embeds: [
            new EmbedBuilder()
              .setColor(0xff4444)
              .setTitle('\u274c \u00dcye Bulunamad\u0131')
              .setDescription('**' + user.name + '** grubun \u00fcyesi de\u011fil veya r\u00fctbesi al\u0131nam\u0131yor.')
              .setFooter({ text: 'Made By discord.gg/pEzT4WmWyn' })
              .setTimestamp()
          ]
        });
      }

      const allRoles = await rbx.fetchGroupRoles();
      const eligible = allRoles
        .filter(function(r) { return r.rank > 0; })
        .sort(function(a, b) { return a.rank - b.rank; });

      const currentIdx = eligible.findIndex(function(r) { return r.id === currentRole.id; });

      if (currentIdx <= 0) {
        return interaction.editReply({
          embeds: [
            new EmbedBuilder()
              .setColor(0xff8800)
              .setTitle('\u26a0\ufe0f Tenzil Edilemiyor')
              .setDescription('**' + user.name + '** zaten en alt r\u00fctbede, daha fazla tenzil edilemiyor.')
              .setFooter({ text: 'Made By discord.gg/pEzT4WmWyn' })
              .setTimestamp()
          ]
        });
      }

      const newRole = eligible[currentIdx - 1];
      await rbx.applyRoleToUser(user.id, newRole.id);

      const embed = new EmbedBuilder()
        .setColor(0xed4245)
        .setTitle('\u2b07\ufe0f Tenzil Ba\u015far\u0131yla Ger\u00e7ekle\u015ftirildi')
        .setDescription('**' + user.name + '** ba\u015far\u0131yla tenzil edildi.')
        .addFields(
          { name: '\uD83D\uDC64 Kullan\u0131c\u0131', value: user.name + '\n`ID: ' + user.id + '`', inline: true },
          { name: '\uD83D\uDCC8 Eski R\u00fctbe', value: currentRole.name + '\n`Rank ' + currentRole.rank + '`', inline: true },
          { name: '\uD83D\uDCC9 Yeni R\u00fctbe', value: newRole.name + '\n`Rank ' + newRole.rank + '`', inline: true },
          { name: '\uD83D\uDCDD Sebep', value: sebep, inline: false },
          { name: '\uD83D\uDD17 Destek Sunucusu', value: '[discord.gg/pEzT4WmWyn](https://discord.gg/pEzT4WmWyn)', inline: false }
        )
        .setFooter({ text: '\u0130\u015flemi Yapan: ' + interaction.user.tag + ' \u2022 Made By discord.gg/pEzT4WmWyn' })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });

      await logger.logAction(client, {
        type: 'TENZIL',
        title: '\u2b07\ufe0f Tenzil \u0130\u015flemi',
        description: '**' + user.name + '** bir alt r\u00fctbeye tenzil edildi.',
        executor: interaction.user,
        targetUser: user.name,
        targetId: user.id,
        oldRole: currentRole,
        newRole: newRole,
        reason: sebep,
        guild: interaction.guild ? interaction.guild.name : 'DM'
      });

    } catch (err) {
      await logger.logAction(null, {
        type: 'HATA',
        title: 'Tenzil Hatas\u0131',
        description: 'Kullan\u0131c\u0131: ' + username,
        extra: '```' + (err.message || String(err)) + '```'
      });

      return interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setColor(0xff4444)
            .setTitle('\u274c \u0130\u015flem Ba\u015far\u0131s\u0131z')
            .setDescription('Tenzil yap\u0131l\u0131rken hata olu\u015ftu:\n```' + (err.message || 'Bilinmeyen hata') + '```')
            .setFooter({ text: 'Made By discord.gg/pEzT4WmWyn' })
            .setTimestamp()
        ]
      });
    }
  }
};
