'use strict';

const axios = require('axios');
const NodeCache = require('node-cache');
const vault = require('../core/vault');

const _cache = new NodeCache({ stdTTL: 180, checkperiod: 60, useClones: false });

const _http = axios.create({
  httpsAgent: vault._tls,
  timeout: 15000,
  headers: {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'tr-TR,tr;q=0.9,en-US;q=0.8',
    'Cache-Control': 'no-cache'
  }
});

const _getCsrf = async function() {
  try {
    await _http.post('https://auth.roblox.com/v2/logout', {}, {
      headers: {
        'Cookie': '.ROBLOSECURITY=' + process.env.ROBLOX_COOKIE
      }
    });
  } catch (err) {
    if (err.response && err.response.headers && err.response.headers['x-csrf-token']) {
      return err.response.headers['x-csrf-token'];
    }
  }
  throw new Error('CSRF token alınamadı. Cookie geçerli mi?');
};

const resolveUsername = async function(username) {
  const ck = 'rbx_user_' + username.toLowerCase();
  if (_cache.has(ck)) return _cache.get(ck);

  const res = await _http.post('https://users.roblox.com/v1/usernames/users', {
    usernames: [username],
    excludeBannedUsers: false
  });

  if (!res.data || !res.data.data || res.data.data.length === 0) return null;
  const u = res.data.data[0];
  _cache.set(ck, u, 90);
  return u;
};

const fetchGroupRoles = async function() {
  const gid = process.env.ROBLOX_GROUP_ID;
  const ck = 'rbx_roles_' + gid;
  if (_cache.has(ck)) return _cache.get(ck);

  const res = await _http.get('https://groups.roblox.com/v1/groups/' + gid + '/roles');
  const sorted = (res.data.roles || []).slice().sort(function(a, b) { return a.rank - b.rank; });
  _cache.set(ck, sorted, 300);
  return sorted;
};

const fetchUserRoleInGroup = async function(userId) {
  const gid = process.env.ROBLOX_GROUP_ID;
  const res = await _http.get('https://groups.roblox.com/v2/users/' + userId + '/groups/roles');
  const groups = res.data.data || [];
  const match = groups.find(function(g) { return String(g.group.id) === String(gid); });
  return match ? match.role : null;
};

const applyRoleToUser = async function(userId, roleId) {
  const gid = process.env.ROBLOX_GROUP_ID;
  const csrf = await _getCsrf();

  await _http.patch(
    'https://groups.roblox.com/v1/groups/' + gid + '/users/' + userId,
    { roleId: roleId },
    {
      headers: {
        'Cookie': '.ROBLOSECURITY=' + process.env.ROBLOX_COOKIE,
        'X-CSRF-TOKEN': csrf,
        'Content-Type': 'application/json'
      }
    }
  );
};

const fetchGameStats = async function() {
  const uid = process.env.UNIVERSE_ID;
  const res = await _http.get('https://games.roblox.com/v1/games?universeIds=' + uid);
  const list = res.data.data || [];
  if (list.length === 0) return null;
  const g = list[0];
  return {
    name: g.name,
    description: g.description,
    playing: g.playing || 0,
    visits: g.visits || 0,
    maxPlayers: g.maxPlayers || 0,
    created: g.created,
    updated: g.updated,
    genre: g.genre || 'Bilinmiyor',
    universeId: g.id,
    rootPlaceId: g.rootPlaceId
  };
};

module.exports = {
  resolveUsername: resolveUsername,
  fetchGroupRoles: fetchGroupRoles,
  fetchUserRoleInGroup: fetchUserRoleInGroup,
  applyRoleToUser: applyRoleToUser,
  fetchGameStats: fetchGameStats
};
