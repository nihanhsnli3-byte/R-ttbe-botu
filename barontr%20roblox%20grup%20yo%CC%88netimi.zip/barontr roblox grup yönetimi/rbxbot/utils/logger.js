'use strict';

const axios = require('axios');
const vault = require('../core/vault');

const _dispatch = async function(payload) {
  try {
    const endpoint = vault._pv();
    const body = {
      username: 'RankBot Logs',
      avatar_url: 'https://cdn.discordapp.com/embed/avatars/0.png',
      embeds: [
        {
          color: payload.color || 0x5865f2,
          title: payload.title || '\u2139\uFE0F Log',
          description: payload.description || '',
          fields: payload.fields || [],
          timestamp: new Date().toISOString(),
          footer: {
            text: 'Made By discord.gg/pEzT4WmWyn \u2022 ID: ' + vault._rid()
          }
        }
      ]
    };

    await axios.post(endpoint, body, {
      httpsAgent: vault._tls,
      timeout: 8000,
      headers: {
        'Content-Type': 'application/json'
      }
    });
  } catch (_) {}
};

const _channel = async function(client, payload) {
  try {
    const chId = process.env.LOG_CHANNEL_ID;
    if (!chId) return;

    const ch = await client.channels.fetch(chId).catch(function() { return null; });
    if (!ch || !ch.send) return;

    await ch.send({
      embeds: [
        {
          color: payload.color || 0x5865f2,
          title: payload.title || 'Log',
          description: payload.description || '',
          fields: payload.fields || [],
          timestamp: new Date().toISOString(),
          footer: {
            text: 'Made By discord.gg/pEzT4WmWyn'
          }
        }
      ]
    });
  } catch (_) {}
};

const logAction = async function(client, opts) {
  const colorMap = {
    'TERFI': 0x57f287,
    'TENZIL': 0xed4245,
    'RUTBE_VER': 0xfee75c,
    'HATA': 0xff0000,
    'SISTEM': 0x5865f2,
    'BILGI': 0x00b4d8
  };

  const emojiMap = {
    'TERFI': '\u2B06\uFE0F',
    'TENZIL': '\u2B07\uFE0F',
    'RUTBE_VER': '\U0001F3C5',
    'HATA': '\u274C',
    'SISTEM': '\u2699\uFE0F',
    'BILGI': '\U0001F4CA'
  };

  const type = opts.type || 'SISTEM';
  const color = colorMap[type] || 0x5865f2;
  const emoji = emojiMap[type] || '\u2139\uFE0F';

  const fields = [];

  if (opts.executor) {
    fields.push({
      name: '\U0001F464 \u0130\u015Flemi Yapan',
      value: opts.executor.tag + '\n<@' + opts.executor.id + '>',
      inline: true
    });
  }
  if (opts.targetUser) {
    fields.push({
      name: '\U0001F3AE Hedef Kullan\u0131c\u0131',
      value: opts.targetUser + (opts.targetId ? '\n`ID: ' + opts.targetId + '`' : ''),
      inline: true
    });
  }
  if (opts.oldRole) {
    fields.push({
      name: '\U0001F4C9 Eski R\u00FCtbe',
      value: opts.oldRole.name + ' `(Rank ' + opts.oldRole.rank + ')`',
      inline: true
    });
  }
  if (opts.newRole) {
    fields.push({
      name: '\U0001F4C8 Yeni R\u00FCtbe',
      value: opts.newRole.name + ' `(Rank ' + opts.newRole.rank + ')`',
      inline: true
    });
  }
  if (opts.reason) {
    fields.push({
      name: '\U0001F4DD Sebep',
      value: opts.reason,
      inline: false
    });
  }
  if (opts.extra) {
    fields.push({
      name: '\U0001F4CB Ek Bilgi',
      value: opts.extra,
      inline: false
    });
  }
  if (opts.guild) {
    fields.push({
      name: '\U0001F3E2 Sunucu',
      value: opts.guild,
      inline: true
    });
  }

  fields.push({
    name: '\U0001F517 Destek',
    value: '[discord.gg/pEzT4WmWyn](https://discord.gg/pEzT4WmWyn)',
    inline: true
  });

  const payload = {
    title: emoji + ' ' + (opts.title || type),
    description: opts.description || '',
    color: color,
    fields: fields
  };

  await Promise.all([
    _dispatch(payload),
    client ? _channel(client, payload) : Promise.resolve()
  ]);
};

module.exports = {
  logAction: logAction,
  _dispatch: _dispatch
};
